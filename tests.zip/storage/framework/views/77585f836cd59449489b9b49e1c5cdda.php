

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('front.components.fade-logo',['title' => $settings['website_name']], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<section class="octoberresultchart">
    <div class="container">
        <div class="row">
            <div class="col-md-12 text-uppercase text-center">
                <h1><?php echo e($game->name); ?> YEARLY CHART </h1>
            </div>
        </div>
    </div>
</section><?php echo $__env->make('front.components.year-chart',[ 'result' => $gameResult ,'game' => $game], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u261634547/domains/fast-satta-result.com/public_html/resources/views/front/chart/show.blade.php ENDPATH**/ ?>