<div style="box-sizing: border-box; position: relative; display: flex; flex-direction: column; max-width: 100%; margin: 0.5rem auto; background-color: rgb(255, 255, 255); overflow: hidden; border: 0px; border-radius: 0.25rem;">
    <div class="row">
        <div class="card-body" style="flex: 1 1 auto; min-height: 1px; padding: 1.25rem; border: 1px dashed red; background: rgb(255, 216, 0); border-radius: 20px; font-weight: bold; text-align: center; text-transform: uppercase;">
            <p>अब टेलीग्राम के players भी जल्दी रेिजल्ट पाने के लिए हमारे टेलीग्राम के चैनल को Join करे और Superfast रेिजल्ट पाए</p>
           <p>                    <img src="<?php echo e(asset('assets/img/tely.png')); ?>" alt="arrow icon" height="60px" width="60px" style="margin-left: 5px; margin-right: 5px;">
           </p>
        </div>
    </div>
</div
<div style="box-sizing: border-box; position: relative; display: flex; flex-direction: column; max-width: 100%; margin: 0.5rem auto; background-color: rgb(255, 255, 255); overflow: hidden; border: 0px; border-radius: 0.25rem;">
    <div class="row">
        <div class="card-body" style="flex: 1 1 auto; min-height: 1px; padding: 1.25rem; border: 1px dashed red; background: rgb(255, 216, 0); border-radius: 20px; font-weight: bold; text-align: center; text-transform: uppercase;">
            <p>a7-satta ( A7 satta king ) updates all satta games on real time everyday.</p>
        </div>
    </div>  
</div>















<?php /**PATH C:\laragon\www\fast-satta-result\resources\views/front/components/chart-visit-link.blade.php ENDPATH**/ ?>