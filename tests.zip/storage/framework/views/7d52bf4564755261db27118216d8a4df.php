

<?php $__env->startSection('content'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u261634547/domains/sattabuzz.com/public_html/resources/views/admin/dashboard/index.blade.php ENDPATH**/ ?>