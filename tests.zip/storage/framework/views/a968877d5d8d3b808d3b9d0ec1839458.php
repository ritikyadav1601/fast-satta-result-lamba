<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>

    <link rel="stylesheet" href=<?php echo e(asset('assets/scss/app.scss')); ?>>
    <link rel="stylesheet" href=<?php echo e(asset('assets/css/admin.css')); ?>>
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://cdn.jsdelivr.net/npm/flowbite@2.5.2/dist/flowbite.min.css" rel="stylesheet" />
    <script defer src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js"></script>

</head>
<body class="bg-gray-100 dark:bg-gray-900">

    <?php echo $__env->make('admin.layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="flex flex-col md:flex-row">

        <!-- Sidebar - hidden on mobile -->
        <aside class="w-full md:w-1/4 lg:w-1/5 bg-white dark:bg-gray-800 hidden md:block">
            <?php echo $__env->make('admin.layout.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </aside>

        <!-- Content Area -->
        <div class="w-full md:w-3/4 lg:w-4/5 p-4">
            <?php echo $__env->yieldContent('content'); ?>
        </div>

    </div>

    <?php echo $__env->make('admin.layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <script src="<?php echo e(asset('node_modules/flowbite/dist/flowbite.js')); ?>"></script>
    <script src="https://cdn.jsdelivr.net/npm/flowbite@2.5.2/dist/flowbite.min.js"></script>

</body>
</html>
<?php /**PATH /home/u261634547/domains/sattabuzz.com/public_html/resources/views/admin/layout/master.blade.php ENDPATH**/ ?>