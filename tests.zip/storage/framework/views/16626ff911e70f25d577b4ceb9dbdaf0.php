<div> footer </div>
<?php /**PATH C:\laragon\www\fast\resources\views/admin/layout/footer.blade.php ENDPATH**/ ?>