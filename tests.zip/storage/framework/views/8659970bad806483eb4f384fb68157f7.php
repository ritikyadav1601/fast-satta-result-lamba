

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('front.components.fade-logo',['title' => $settings['website_name']], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<section class="forChart">
    <h2 class="ql-indent-2 ql-align-center"><strong>For any enquiry message us at </strong><strong style="color: rgb(33, 37, 41);">hello@fast-satta-result.com</strong></h2>
    <p><br></p>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\fast-satta-result\resources\views/front/contact/index.blade.php ENDPATH**/ ?>