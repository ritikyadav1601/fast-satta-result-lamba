<div> footer </div>
<?php /**PATH /home/u261634547/domains/fast-satta-result.com/public_html/resources/views/admin/layout/footer.blade.php ENDPATH**/ ?>