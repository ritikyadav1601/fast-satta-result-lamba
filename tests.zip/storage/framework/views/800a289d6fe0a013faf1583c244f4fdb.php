<section class="tablebox1" style="margin: 0px 0px 5px;">
    <div class="container-fluid">
        <div class="row">
            <article style="padding: 0px;">
                <div class="col-md-12 nopadding" style="margin-bottom: 20px;">
                    <div class="table-responsive">
                        <table class="table table-bordered">
                            <thead class="forblack">
                                <tr>
                                    <th class="col-md-4 text-center" style="width: 37%; background: rgb(0, 0, 0); color: rgb(255, 255, 255);">सट्टा का नाम</th>
                                    <th class="col-md-4 text-center" style="background: rgb(0, 0, 0); color: rgb(255, 255, 255);">कल आया था</th>
                                    <th class="col-md-4 text-center" style="background: rgb(0, 0, 0); color: rgb(255, 255, 255);">आज का रिज़ल्ट</th>
                                </tr>
                            </thead>
                            <?php $__currentLoopData = $games; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $game): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tbody>
                                <tr>
                                    <td class="foryellow">
                                        <a class="gamenameeach" href="<?php echo e(route('game.show', $game->id)); ?>"><?php echo e($game->name); ?></a><br> 
                                        <!-- Format the time to 12-hour format with AM/PM -->
                                        <?php echo e(\Carbon\Carbon::parse($game->time)->format('h:i A')); ?><br>
                                    </td>
                        
                                    <td class="yesterday-number">
                                        <div class="special-bold" style="margin-bottom: 0px; letter-spacing: 2px; font-size: 22px;">
                                            <?php echo e($game->yesterday_result); ?>

                                        </div>
                                    </td>


                                    <td class="today-number">
                                        <div style="margin-bottom: 0px; letter-spacing: 2px; font-size: 22px;">
                                            <?php if(\Carbon\Carbon::now('Asia/Kolkata')->format('H:i') < $game->time): ?>
                                                <img style="width: 40px; height: 40px;" src="<?php echo e(asset('assets/img/clock.gif')); ?>" alt="wait icon">
                                            <?php else: ?>
                                                <?php echo e($game->today_result); ?>

                                            <?php endif; ?>
                                        </div>
                                    </td>
                                </tr>
                            </tbody>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                        
                        </table>
                    </div>
                </div>
            </article>
            
           
        </div>
    </div>
</section><?php /**PATH C:\laragon\www\sattabuzz\resources\views/front/components/daily-result-table.blade.php ENDPATH**/ ?>