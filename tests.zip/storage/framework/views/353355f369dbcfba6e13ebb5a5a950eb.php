<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>J7 Satta</title>
    <link rel="icon" type="image/x-icon" href="<?php echo e(asset('assets/img/logo.png')); ?>">
    <link rel="stylesheet" href=<?php echo e(asset('assets/css/main.css')); ?>>
    <?php echo $__env->yieldPushContent('style'); ?>
    <!-- Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-Y0Z9RQNR0D"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-Y0Z9RQNR0D');
</script>
</head>
<body>
<?php echo $__env->make('front.layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->yieldContent('content'); ?>

<?php echo $__env->make('front.layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->yieldPushContent('script'); ?>

</body>
</html>
<?php /**PATH /home/u261634547/domains/j7satta.com/public_html/resources/views/front/layout/master.blade.php ENDPATH**/ ?>