<section class="octoberresultchart">
    <div class="container">
        <div class="row">
            <div class="col-md-12 text-center">
                <h5>SATTA RECORD CHART 2024</h5>
            </div>
        </div>
    </div>
</section>

<section class="octoberresultchart">
    <div class="container">
        <div class="row">
            <div class="col-md-12 text-center">
                <h1><?php echo e(strtoupper(now()->format('Y F'))); ?> RESULT CHART</h1>
            </div>
        </div>
    </div>
</section>

<section class="newtable">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12 nopadding">
                <div class="table-responsive marginBottom">
                    <table class="table table-bordered table-extra">
                        <thead>
                            <tr>
                                <td class="table_chart_section_01 forfirtcolor date col-md-2 text-center">
                                    <strong class="fon">Date</strong>
                                </td>
                                <?php $__currentLoopData = $games; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $game): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <td class="table_chart_section forfirtcolor text-center">
                                        <?php echo e(strtoupper($game->name)); ?>

                                    </td>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $dates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $date): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="forfirtcolor text-center">
                                        <span class="fon"><?php echo e(date('d-m', strtotime($date))); ?></span>
                                    </td>
                                    <?php $__currentLoopData = $games; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $game): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <td>
                                            <span class="table_chart_section_02">
                                                <?php echo e(isset($this_year_results[$date][$game->id]) ? $this_year_results[$date][$game->id]->first()->result : '-'); ?>

                                            </span>
                                        </td>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                        
                    </table>
                </div>
            </div>
        </div>
    </div>
</section>
<?php /**PATH C:\laragon\www\sattabuzz\resources\views/front/components/record-chart.blade.php ENDPATH**/ ?>