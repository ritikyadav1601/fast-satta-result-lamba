

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('front.components.fade-logo',['title' => $settings['website_name']], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<section class="circlebox">
    <div class="container">
        <div class="row">
            <div class="col-md-12 text-center">
                <div class="liveresult">
                    <h1 class="hintext2">Satta 24 provides all kind of satta king results everyday.</h1>
                </div>
            </div>
        </div>
    </div>
</section>
<section class="octoberresultchart">
    <div class="container">
        <div class="row">
            <div class="col-md-12 text-center">
                <h2>SATTA KING CHART</h2>
            </div>
        </div>
    </div>
</section>

<section class="newtable">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12 nopadding">
                <div class="table-responsive marginBottom">
                    <table class="table table-bordered table-extra">
                        <thead>
                            <tr>
                                <th class="table_chart_section forfirtcolor text-center">Game</th>
                                <th class="table_chart_section forfirtcolor text-center">2024</th>
                                <th class="table_chart_section forfirtcolor text-center">2023</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $games; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $game): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                               
                                    <td class="table_chart_section forfirtcolor text-center">
                                        <?php echo e(strtoupper($game->name)); ?>

                                    </td>
                                    <td class="  text-center">
                                     <a href="<?php echo e(route('game.show', $game->id)); ?>?year=2024">2024</a>
                                    </td>
                                    <td class="  text-center">
                                     <a href="<?php echo e(route('game.show', $game->id)); ?>?year=2023">2023</a>
                                    </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>
                
                        
                    </table>
                </div>
            </div>
        </div>
    </div>
</section>

<?php echo $__env->make('front.components.chart-links', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\stz\resources\views/front/chart/index.blade.php ENDPATH**/ ?>