


<?php /**PATH /home/u261634547/domains/sattabuzz.com/public_html/resources/views/front/components/chart-links.blade.php ENDPATH**/ ?>