<div> footer </div>
<?php /**PATH C:\laragon\www\sattabuzz\resources\views/admin/layout/footer.blade.php ENDPATH**/ ?>