<div> footer </div>
<?php /**PATH C:\laragon\www\j7\resources\views/admin/layout/footer.blade.php ENDPATH**/ ?>