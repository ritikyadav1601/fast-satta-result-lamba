<?php $__env->startSection('content'); ?>
<?php echo $__env->make('front.components.fade-logo',['title' => $settings['website_name']], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<section class="octoberresultchart">
    <div class="container">
        <div class="row">
            <div class="col-md-12 text-uppercase text-center">
                <h1><?php echo e($game->name); ?> YEARLY CHART </h1>
                <div style="margin: 20px 0;">
                    <form action="<?php echo e(route('extra-game.show', $game->id)); ?>" method="GET" class="form-inline" style="display: inline-block;">
                        <label for="year" style="font-size: 18px; margin-right: 10px; color: #fff;">Select Year:</label>
                        <select name="year" id="year" class="form-control" onchange="this.form.submit()" style="display: inline-block; width: auto; font-size: 16px; padding: 5px 10px; border-radius: 5px;">
                            <?php
                                $currentYear = date('Y');
                                $selectedYear = request()->year ?? $currentYear;
                            ?>
                            <?php for($i = $currentYear; $i >= 2015; $i--): ?>
                                <option value="<?php echo e($i); ?>" <?php echo e($selectedYear == $i ? 'selected' : ''); ?>><?php echo e($i); ?></option>
                            <?php endfor; ?>
                        </select>
                    </form>
                </div>
            </div>
        </div>
    </div>
</section><?php echo $__env->make('front.components.year-chart',[ 'result' => $gameResult ,'game' => $game], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\fast\resources\views/front/chart/extra-show.blade.php ENDPATH**/ ?>