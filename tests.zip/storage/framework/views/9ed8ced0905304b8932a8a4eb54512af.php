<div> footer </div>
<?php /**PATH C:\laragon\www\stz\resources\views/admin/layout/footer.blade.php ENDPATH**/ ?>