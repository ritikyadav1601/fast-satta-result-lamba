


<?php /**PATH C:\laragon\www\fast-satta-result\resources\views/front/components/chart-links.blade.php ENDPATH**/ ?>