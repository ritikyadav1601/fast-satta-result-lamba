<div class="forChart">
    <h5 class="ql-align-center"><strong>Satta Buzz - The World's Best Satta Bazar Website</strong></h5>
    <?php $__currentLoopData = $qa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $quews): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        
    
    <h5 class="ql-align-center"><strong><?php echo e($quews->question); ?></strong></h5>
    <p><?php echo e($quews->answer); ?></p>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
    
    
        <h5 class="ql-align-center"><strong>Frequently Asked Question About Satta Buzz</strong></h5>
        <?php $__currentLoopData = $faq; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $quews): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            
        
    <h5 class="ql-align-center"><strong><?php echo e($quews->question); ?></strong></h5>
    <p><?php echo e($quews->answer); ?></p>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div><?php /**PATH /home/u261634547/domains/sattabuzz.com/public_html/resources/views/front/components/faq.blade.php ENDPATH**/ ?>