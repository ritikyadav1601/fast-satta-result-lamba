<?php
    use Carbon\Carbon;$disawar = $games->where('english_name', 'disawar')->first();
?>
<section class="octoberresultchart">
    <div class="container">
        <div class="row">
            <div class="col-md-12 text-center">
                <h3>Satta Chart, Faridabad Satta, Ghaziabad Result</h3>
            </div>
        </div>
    </div>
</section>
<?php $__currentLoopData = $gamess; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $games): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <section class="tablebox1" style="margin: 0px 0px 5px;">
        <div class="container-fluid">
            <div class="row">
                <article style="padding: 0px;">
                    <div class="col-md-12 nopadding" style="margin-bottom: 20px;">
                        <div class="table-responsive">
                            <table class="table table-bordered">
                                <thead class="forblack">
                                <tr>
                                    <th class="col-md-4 text-center"
                                        style="width: 37%; background: rgb(0, 0, 0); color: rgb(255, 255, 255);">सट्टा
                                        का नाम
                                    </th>
                                    <th class="col-md-4 text-center"
                                        style="background: rgb(0, 0, 0); color: rgb(255, 255, 255);">कल आया था
                                    </th>
                                    <th class="col-md-4 text-center"
                                        style="background: rgb(0, 0, 0); color: rgb(255, 255, 255);">आज का रिज़ल्ट
                                    </th>
                                </tr>
                                </thead>
                                
                                <?php $__currentLoopData = $games; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $game): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tbody>
                                    <?php if($game->english_name != 'disawar'): ?>
                                        <tr>
                                            <td class="foryellow">
                                                <a class="gamenameeach"
                                                   href="<?php echo e(route('game.show', $game->id)); ?>"><?php echo e($game->name); ?></a><br>
                                                <?php echo e(Carbon::parse($game->result_time)->format('h:i A')); ?><br>
                                            </td>
                                            <td class="yesterday-number">
                                                <div class="special-bold"
                                                     style="margin-bottom: 0px; letter-spacing: 2px; font-size: 22px;">
                                                    <?php if($game->yesterday_result == 100): ?>
                                                        00
                                                    <?php elseif($game->yesterday_result == null): ?>
                                                    --
                                                    <?php else: ?>
                                                        <?php echo e(str_pad($game->yesterday_result, 2, '0', STR_PAD_LEFT) ?? '--'); ?>

                                                    <?php endif; ?>

                                                </div>
                                            </td>
                                            <td class="today-number">
                                                <div style="margin-bottom: 0px; letter-spacing: 2px; font-size: 22px;">
                                                    <?php if(Carbon::now('Asia/Kolkata')->format('H:i') < $game->result_time): ?>
                                                        <img style="width: 40px; height: 40px;"
                                                             src="<?php echo e(asset('assets/img/wait.gif')); ?>" alt="wait icon">
                                                    <?php else: ?>
                                                        <?php if($game->today_result == 100): ?>
                                                            00
                                                        <?php elseif($game->today_result == null): ?>
                                                        --
                                                        <?php else: ?>
                                                            <?php if(!empty($game->today_result)): ?>
                                                                <?php echo e(str_pad($game->today_result, 2, '0', STR_PAD_LEFT)); ?>

                                                            <?php else: ?>
                                                                <img style="width: 40px; height: 40px;"
                                                                     src="<?php echo e(asset('assets/img/wait.gif')); ?>"
                                                                     alt="wait icon">
                                                            <?php endif; ?>
                                                        <?php endif; ?>
                                                    <?php endif; ?>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endif; ?>
                                    </tbody>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                <!--<tbody>-->
                                <!--<tr>-->
                                <!--    <td class="foryellow"><a class="gamenameeach"-->
                                <!--                             href="<?php echo e(route('game.show', $disawar->id)); ?>"><?php echo e($disawar->name); ?></a><br> <?php echo e(Carbon::parse($disawar->result_time)->format('h:i A')); ?>-->
                                <!--        <br></td>-->
                                <!--    <td class="yesterday-number">-->
                                <!--        <div class="special-bold"-->
                                <!--             style="margin-bottom: 0px; letter-spacing: 2px; font-size: 22px;">-->
                                <!--            <?php if($disawar->yesterday_result == 100): ?>-->
                                <!--                00-->
                                <!--            <?php else: ?>-->
                                <!--                <?php if(!empty($disawar->yesterday_result)): ?>-->
                                <!--                    <?php echo e(str_pad($disawar->yesterday_result, 2, '0', STR_PAD_LEFT)); ?>-->
                                <!--                <?php else: ?>-->
                                <!--                    <img style="width: 40px; height: 40px;"-->
                                <!--                         src="<?php echo e(asset('assets/img/wait.gif')); ?>" alt="wait icon">-->
                                <!--                <?php endif; ?>-->
                                <!--            <?php endif; ?>-->
                                <!--        </div>-->
                                <!--    </td>-->
                                <!--    <td class="today-number">-->
                                <!--        <div style="margin-bottom: 0px; letter-spacing: 2px; font-size: 22px;">-->
                                <!--            <?php if($disawar->today_result == 100): ?>-->
                                <!--                00-->
                                <!--            <?php else: ?>-->
                                <!--                <?php if(!empty($disawar->today_result)): ?>-->
                                <!--                    <?php echo e(str_pad($disawar->today_result, 2, '0', STR_PAD_LEFT)); ?>-->
                                <!--                <?php else: ?>-->
                                <!--                    <img style="width: 40px; height: 40px;"-->
                                <!--                         src="<?php echo e(asset('assets/img/wait.gif')); ?>" alt="wait icon">-->
                                <!--                <?php endif; ?>-->
                                <!--            <?php endif; ?>-->
                                <!--        </div>-->
                                <!--    </td>-->
                                <!--</tr>-->
                                <!--</tbody>-->
                            </table>
                        </div>
                    </div>
                </article>
            </div>
        </div>
    </section>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<div class="column-ad card-body"
     style="box-sizing: border-box; flex: 1 1 auto; min-height: 1px; padding: 1rem 0.5rem; border: dashed red; background: linear-gradient(rgb(255, 216, 0), rgb(255, 255, 255)); border-radius: 20px; font-weight: bold; margin-top: 5px; margin-bottom: 5px;">
    <p>🙏🏿नमस्कार साथियो 🙏🏿</p>
    <p>किसी भी तरह की कोई शिकायत के लिए कंपनी के मैनेजर से संपर्क करे &nbsp; &nbsp;</p>
    <p>----<?php echo e(strtoupper($settings['owner_name'])); ?> ----</p>
    <p><a href="<?php echo e('https://wa.me/' . $settings['owner_number']); ?>"><img
                src="<?php echo e(asset('assets/img/whatsapp.png')); ?>"
                alt="Whatsapp to show game on this website"></a></p>
    <p>NOTE: &nbsp; इस नंबर पर लीक गेम नही मिलता गेम लेने वाले भाई कॉल या मैसेज न करें।</p>
    <p>किसी भी भाई को किसी भी तरह की कोई शिकायत या परेशानी हो तो हमसे telegram पर संपर्क करे</p>
    <p><a href="<?php echo e('https://t.me/' . $settings['owner_number']); ?>"><img
                src="<?php echo e(asset('assets/img/tel.webp')); ?>"
                alt="Telegram link to show game"></a></p></div>
                

<?php /**PATH C:\laragon\www\fast\resources\views/front/components/daily-result-table.blade.php ENDPATH**/ ?>