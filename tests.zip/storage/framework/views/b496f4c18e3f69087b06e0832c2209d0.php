

<?php $__env->startSection('content'); ?>
<div class="relative overflow-x-auto shadow-md sm:rounded-lg">
    <div class="flex justify-between">
        <div class="flex items-center justify-between p-4">
            <h5 class="text-xl font-bold leading-none text-gray-900 dark:text-white">Update Game Result</h5>
        </div>
    </div>

    <table class="w-full text-sm text-left rtl:text-right text-gray-500 dark:text-gray-400">
        <thead class="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400">
            <tr>
                <th scope="col" class="px-6 py-3">Game Name</th>
                <th scope="col" class="px-6 py-3">Result Time</th>
                <th scope="col" class="px-6 py-3">Result</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $games; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $game): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <tr class="odd:bg-white odd:dark:bg-gray-900 even:bg-gray-50 even:dark:bg-gray-800 border-b dark:border-gray-700">
                <th scope="row" class="px-6 py-4 font-medium text-gray-900 whitespace-nowrap dark:text-white">
                    <?php echo e($game->name); ?>

                </th>
                <td class="px-6 py-4"><?php echo e(\Carbon\Carbon::parse($game->result_time)->format('g:i A')); ?></td>

                <!-- Add an input field and a button for updating the result -->
                <td class="px-6 py-4">
                    <form action="<?php echo e(route('admin.game.result.update', $game->id)); ?>" method="POST" class="flex">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <input type="text" name="result" value="<?php echo e($game->gameResult?->first()?->result); ?>"  class="border rounded px-2 py-1 mr-2" placeholder="Enter result">
                        <button type="submit" class="bg-blue-600 text-white px-4 py-1 rounded hover:bg-blue-700">Update</button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u261634547/domains/j7satta.com/public_html/resources/views/admin/game/result.blade.php ENDPATH**/ ?>