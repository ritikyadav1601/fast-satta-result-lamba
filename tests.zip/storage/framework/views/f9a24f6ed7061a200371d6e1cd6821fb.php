<section class="circlebox">
    <div class="container">
        <div class="row">
            <div class="col-md-12 text-center">
                <div class="liveresult">
                    <div id="clockbox"></div>
                    <p class="hintext" style="padding: 0px;">हा भाई यही आती हे सबसे पहले खबर रूको और देखो</p>
                </div>
            </div>
        </div>
    </div>
</section>
<section class="circlebox2">
    <?php
        $game = $games->where('time', '>=', \Carbon\Carbon::now('Asia/Kolkata')->format('H:i'))->first();
        $disawar = $games->where('english_name', 'disawar')->first();
    ?>
    <div>
        <div class="sattaname">
            <p style="margin: 0px;"><?php echo e($game->name); ?></p>
        </div>
        <div class=" sattaresult">
            <p style="margin: 0px; padding: 0px;">
                <?php if(\Carbon\Carbon::now('Asia/Kolkata')->format('H:i') < $game->time): ?>
                <img style="width: 60px; height: 60px;" src="<?php echo e(asset('assets/img/wait.gif')); ?>" alt="wait icon">
                <?php else: ?>
                <?php echo e($game?->todayResult()?->result); ?>

<?php endif; ?>
            </p>
        </div>
    </div>
</section>
<div class="wrapper-yellow">
    <section class="sattadividerr">
        <div class="container">
            <div class="col-md-12 text-center" style="padding-bottom: 15px;">
                <h4 style="font-size: 24px; font-weight: normal; text-transform: uppercase; margin: 0px; padding: 0px;">Disawer</h4>
                <p style="font-size: 18px; font-weight: 400;"><?php echo e(\Carbon\Carbon::parse($disawar?->time)->format('g:i A')); ?></p>
                <strong style="font-size: 20px; letter-spacing: 2px;"><?php echo e($disawar->yesterdayResult()->result ?? '-'); ?><img src="<?php echo e(asset('assets/img/arrow.gif')); ?>" alt="arrow icon" height="30px" width="30px" style="margin-left: 5px; margin-right: 5px;"><?php echo e($disawar->todayResult()->result ?? '-'); ?></strong></div>
        </div>
    </section>
</div>

<script>
    function updateClock() {
        var now = new Date();
        var options = { year: 'numeric', month: 'long', day: 'numeric', hour: 'numeric', minute: 'numeric', second: 'numeric', hour12: true };
        var timeString = now.toLocaleString('en-US', options);
        document.getElementById('clockbox').innerHTML = timeString;
    }
    
    // Update the clock every second
    setInterval(updateClock, 1000);
    
    // Initial call to display the current time right away
    updateClock();
    </script><?php /**PATH C:\laragon\www\sattabuzz\resources\views/front/components/updated-box.blade.php ENDPATH**/ ?>