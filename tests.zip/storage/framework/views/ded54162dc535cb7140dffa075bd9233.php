<?php $__env->startSection('meta_title', $blog->meta_title); ?>
<?php $__env->startSection('meta_description', $blog->meta_description); ?>
<?php $__env->startSection('meta_keywords', $blog->meta_keywords); ?>
<?php $__env->startSection('canonical', $blog->canonical_url); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('front.components.fade-logo',['title' => $settings['website_name']], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<section class="octoberresultchart">
    <div class="container mx-auto px-4 py-12">
        <div class="max-w-4xl mx-auto">
            <!-- Featured Image -->
            <?php if($blog->featured_image): ?>
            <div class="mb-8 rounded-lg overflow-hidden shadow-lg">
                <img src="<?php echo e(asset('storage/app/public/' . $blog->featured_image)); ?>" 
                     alt="<?php echo e($blog->title); ?>" 
                     class="w-full h-96 object-cover">
            </div>
            <?php endif; ?>

            <!-- Blog Content -->
            <article class="bg-white rounded-lg shadow-md p-8">
                <!-- Category and Date -->
                <div class="flex items-center justify-between mb-6">
                    <?php if($blog->category): ?>
                    <span class="px-4 py-1 text-sm font-semibold text-white bg-blue-600 rounded-full">
                        <?php echo e($blog->category); ?>

                    </span>
                    <?php endif; ?>
                    <div class="flex items-center space-x-2 text-gray-500">
                        <svg height=20 width=20 class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"></path>
                        </svg>
                        <span><?php echo e($blog->created_at->format('F d, Y')); ?></span>
                    </div>
                </div>

                <!-- Title -->
                <h1 class="text-3xl font-bold text-gray-800 mb-6"><?php echo e($blog->title); ?></h1>
                <div class=" text-gray-700">
                    <?php echo $blog->description; ?>

                </div>
                <!-- Tags -->
                <?php if($blog->tags): ?>
                <div class="flex flex-wrap gap-2 mb-8">
                    <?php $__currentLoopData = explode(',', $blog->tags); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <span class="px-3 py-1 text-sm text-gray-600 bg-gray-100 rounded-full">
                        #<?php echo e(trim($tag)); ?>

                    </span>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <?php endif; ?>

                <!-- Content -->
                

                
            </article>

            <!-- Related Posts -->
            <?php if(isset($relatedBlogs) && $relatedBlogs->count() > 0): ?>
            <div class="mt-16">
                <h2 class="text-2xl font-bold text-gray-800 mb-8">Related Posts</h2>
                <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                    <?php $__currentLoopData = $relatedBlogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $relatedBlog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="bg-white rounded-lg shadow-md overflow-hidden">
                        <?php if($relatedBlog->featured_image): ?>
                        <div class="relative h-48 overflow-hidden">
                            <img src="<?php echo e(asset('storage/' . $relatedBlog->featured_image)); ?>" 
                                 alt="<?php echo e($relatedBlog->title); ?>" 
                                 class="w-full h-full object-cover">
                        </div>
                        <?php endif; ?>
                        <div class="p-6">
                            <h3 class="text-xl font-bold text-gray-800 mb-2">
                                <a href="<?php echo e(route('front.single.blog', $relatedBlog->slug)); ?>" class="hover:text-blue-600">
                                    <?php echo e($relatedBlog->title); ?>

                                </a>
                            </h3>
                            <p class="text-gray-600 line-clamp-2">
                                <?php echo Str::limit(strip_tags($relatedBlog->description), 100); ?>

                            </p>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            <?php endif; ?>
        </div>
    </div>
</section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u261634547/domains/fast-satta-result.com/public_html/resources/views/front/blogs/show.blade.php ENDPATH**/ ?>