<section class="tablebox1" style="margin: 0px 0px 5px;">
    <div class="container-fluid">
        <div class="row">
            <article style="padding: 0px;">
                <div class="col-md-12 nopadding" style="margin-bottom: 20px;">
                    <div class="table-responsive">
                        <table class="table table-bordered">
                            <thead class="forblack">
                                <tr>
                                    <th class="col-md-4 text-center" style="width: 37%; background: rgb(0, 0, 0); color: rgb(255, 255, 255);">सट्टा का नाम</th>
                                    <th class="col-md-4 text-center" style="background: rgb(0, 0, 0); color: rgb(255, 255, 255);">कल आया था</th>
                                    <th class="col-md-4 text-center" style="background: rgb(0, 0, 0); color: rgb(255, 255, 255);">आज का रिज़ल्ट</th>
                                </tr>
                            </thead>
                            <?php $__currentLoopData = $games; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $game): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tbody>
                                <?php if($game->english_name != 'disawar'): ?>
                                <tr>
                                    <td class="foryellow">
                                        <a class="gamenameeach" href="<?php echo e(route('game.show', $game->id)); ?>"><?php echo e($game->name); ?></a><br> 
                                        
                                        <?php echo e(\Carbon\Carbon::parse($game->result_time)->format('h:i A')); ?><br>
                                    </td>
                        
                                    <td class="yesterday-number">
                                        <div class="special-bold" style="margin-bottom: 0px; letter-spacing: 2px; font-size: 22px;">
                                            <?php if($game->yesterday_result == 100): ?>
                                            00
                                            <?php else: ?>
                                            <?php echo e(str_pad($game->yesterday_result, 2, '0', STR_PAD_LEFT)); ?>

                                            <?php endif; ?>

                                        </div>
                                    </td>


                                    <td class="today-number">
                                        <div style="margin-bottom: 0px; letter-spacing: 2px; font-size: 22px;">
                                            <?php if(\Carbon\Carbon::now('Asia/Kolkata')->format('H:i') < $game->result_time): ?>
                                                <img style="width: 40px; height: 40px;" src="<?php echo e(asset('assets/img/wait.gif')); ?>" alt="wait icon">
                                                <?php else: ?>
                                               <?php if($game->today_result == 100): ?>
                                                00
                                                <?php else: ?>
                                                <?php echo e(str_pad($game->today_result, 2, '0', STR_PAD_LEFT)); ?>

                                                <?php endif; ?>
                                            <?php endif; ?>
                                        </div>
                                    </td>
                                </tr>
                                <?php endif; ?>
                            </tbody>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $disawar = $games->where('english_name', 'disawar')->first();
                        ?>
                        <tbody>
                            <tr>
                                <td class="foryellow"><a class="gamenameeach" href="<?php echo e(route('game.show', $disawar->id)); ?>"><?php echo e($disawar->name); ?></a><br> <?php echo e(\Carbon\Carbon::parse($disawar->result_time)->format('h:i A')); ?><br></td>
                                <td class="yesterday-number">
                                    <div class="special-bold" style="margin-bottom: 0px; letter-spacing: 2px; font-size: 22px;">
                                        <?php if($disawar->yesterday_result == 100): ?>
                                        00
                                        <?php else: ?>
                                        <?php echo e(str_pad($disawar->yesterday_result, 2, '0', STR_PAD_LEFT) ?? '--'); ?>

                                        <?php endif; ?>
                                        </div>
                                </td>
                                <td class="today-number">
                                    <div style="margin-bottom: 0px; letter-spacing: 2px; font-size: 22px;">
                                        <?php if($disawar->today_result == 100): ?>
                                        00
                                        <?php else: ?>
                                        <?php echo e(str_pad($disawar->today_result, 2, '0', STR_PAD_LEFT) ?? '--'); ?>

                                        <?php endif; ?>
                                        </div>
                                </td>
                            </tr>
                        </tbody>
                        </table>
                    </div>
                </div>
            </article>
            
           
        </div>
    </div>
</section><?php /**PATH C:\laragon\www\24king\resources\views/front/components/daily-result-table.blade.php ENDPATH**/ ?>