<section class="octoberresultchart">
    <div class="container">
        <div class="row">
            <div class="col-md-12 text-center">
                <h1>Fast Satta Result – Live 2025 Updates</h1>
            </div>
        </div>
    </div>
</section>
<section class="octoberresultchart">
    <div class="container">
        <div class="row">
            <div class="col-md-12 text-center">
                <h2>Today Satta Result, Gali Satta King, Desawar Satta King , Fast Satta King</h2>
            </div>
        </div>
    </div>
</section>

<section class="octoberresultchart">
    <div class="container">
        <div class="row">
            <div class="col-md-12 text-center">
                <h3><?php echo e(strtoupper(now()->format('Y F'))); ?> RESULT CHART</h3>
            </div>
        </div>
    </div>
</section>
<?php
$selectedArray = ['फरीदाबाद', 'गाज़ियाबाद', 'गली', 'दिसावर'];
$selectedGames = $games->whereIn('name', $selectedArray);
 
?>

<section class="newtable">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12 nopadding">
                <div class="table-responsive marginBottom">
                    <table class="table table-bordered table-extra">
                        <thead>
                            <tr>
                                <td class="table_chart_section_01 forfirtcolor date col-md-2 text-center">
                                    <strong class="fon">Date</strong>
                                </td>
                                <?php $__currentLoopData = $selectedGames; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $game): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <td class="table_chart_section forfirtcolor text-center">
                                        <?php echo e(strtoupper($game->name)); ?>

                                    </td>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $dates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $date): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($date <= now()): ?>
    <tr>
        <td class="forfirtcolor text-center">
            <span class="fon"><?php echo e(date('d-m', strtotime($date))); ?></span>
        </td>
        <?php $__currentLoopData = $selectedGames; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $game): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <td>
                <span class="table_chart_section_02">
                    <?php
                        $currentDate = \Carbon\Carbon::now('Asia/Kolkata')->format('Y-m-d');
                        $currentTime = \Carbon\Carbon::now('Asia/Kolkata')->format('H:i');
                    ?>

                    <?php if($currentDate == $date): ?>
                        
                        <?php if($currentTime >= $game->result_time): ?>
                            <?php if(isset($this_year_results[$date][$game->id]) && $this_year_results[$date][$game->id]->first()->result == 100): ?>
                                00
                            <?php else: ?>
                                <?php echo e(isset($this_year_results[$date][$game->id]) ? str_pad($this_year_results[$date][$game->id]->first()->result, 2, '0', STR_PAD_LEFT) : '-'); ?>

                            <?php endif; ?>
                        <?php else: ?>
                            -- 
                        <?php endif; ?>
                    <?php else: ?>
                        
                        <?php if(isset($this_year_results[$date][$game->id])): ?>
                            <?php if($this_year_results[$date][$game->id]->first()->result == 100): ?>
                                00
                            <?php else: ?>
                                <?php echo e(str_pad($this_year_results[$date][$game->id]->first()->result, 2, '0', STR_PAD_LEFT)); ?>

                            <?php endif; ?>
                        <?php else: ?>
                            --
                        <?php endif; ?>
                    <?php endif; ?>
                </span>
            </td>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tr>
    <?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                        
                    </table>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="newtable">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12 nopadding">
                <div class="table-responsive marginBottom">
                    <table class="table table-bordered table-extra">
                        <thead>
                            <tr>
                                <td class="table_chart_section_01 forfirtcolor date col-md-2 text-center">
                                    <strong class="fon">Date</strong>
                                </td>
                                <?php $__currentLoopData = $games->whereNotIn('name', $selectedArray); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $game): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <td class="table_chart_section forfirtcolor text-center">
                                        <?php echo e(strtoupper($game->name)); ?>

                                    </td>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $dates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $date): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($date <= now()): ?>
    <tr>
        <td class="forfirtcolor text-center">
            <span class="fon"><?php echo e(date('d-m', strtotime($date))); ?></span>
        </td>
        <?php $__currentLoopData = $games->whereNotIn('name', $selectedArray); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $game): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <td>
                <span class="table_chart_section_02">
                    <?php
                        $currentDate = \Carbon\Carbon::now('Asia/Kolkata')->format('Y-m-d');
                        $currentTime = \Carbon\Carbon::now('Asia/Kolkata')->format('H:i');
                    ?>

                    <?php if($currentDate == $date): ?>
                        
                        <?php if($currentTime >= $game->result_time): ?>
                            <?php if(isset($this_year_results[$date][$game->id]) && $this_year_results[$date][$game->id]->first()->result == 100): ?>
                                00
                            <?php else: ?>
                                <?php echo e(isset($this_year_results[$date][$game->id]) ? str_pad($this_year_results[$date][$game->id]->first()->result, 2, '0', STR_PAD_LEFT) : '-'); ?>

                            <?php endif; ?>
                        <?php else: ?>
                            -- 
                        <?php endif; ?>
                    <?php else: ?>
                        
                        <?php if(isset($this_year_results[$date][$game->id])): ?>
                            <?php if($this_year_results[$date][$game->id]->first()->result == 100): ?>
                                00
                            <?php else: ?>
                                <?php echo e(str_pad($this_year_results[$date][$game->id]->first()->result, 2, '0', STR_PAD_LEFT)); ?>

                            <?php endif; ?>
                        <?php else: ?>
                            --
                        <?php endif; ?>
                    <?php endif; ?>
                </span>
            </td>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tr>
    <?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                        
                    </table>
                </div>
            </div>
        </div>
    </div>
</section>

<?php /**PATH C:\laragon\www\fast\resources\views/front/components/record-chart.blade.php ENDPATH**/ ?>