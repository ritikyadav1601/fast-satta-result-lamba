<?php $__env->startSection('title', 'Fast Satta Result | Satta Fast, Faridabad, King, Satta King'); ?>
<?php $__env->startSection('meta_description', 'Fast Satta Result par paye satta fast result, Faridabad satta fast, satta king info aur 36 jodi telegram chart bilkul free. Aaj ka result dekhein abhi!.'); ?>
<?php $__env->startSection('meta_keywords', 'home, awesome site, welcome,fast satta king'); ?>
<?php $__env->startSection('canonical'); ?>
<link rel="canonical" href="https://fast-satta-result.com/" />
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('front.components.fade-logo' ,['title' => $settings['website_name']], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('front.components.updated-box',['games' => $games, 'gamess' => $gamess], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
 <?php echo $__env->make('front.components.chart-visit-link', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('front.components.home-timing-detail',['games' => $games,'settings' => $settings,'otherChart' => $otherChart], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->make('front.components.daily-result-table',['games' => $games], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php if($extraGames->count() > 0): ?>
    <?php echo $__env->make('front.components.extra-daily-result-table',['extraGames' => $extraGames], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?>
    <?php echo $__env->make('front.components.record-chart', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('front.components.faq',['faq' => $faq , 'qa' => $qa], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\fast\resources\views/front/index.blade.php ENDPATH**/ ?>