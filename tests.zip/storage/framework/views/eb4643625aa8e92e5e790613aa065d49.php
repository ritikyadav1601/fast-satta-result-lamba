<section class="sattalogo">
    <div class="container">
        <div class="row">
            <div class="col-md-12 text-center">
                <a title="A1-Satta" href="/" class="blink" style="display: inline; opacity: 0.877126;">
                    <h1 style="margin: 0px; font-weight: 700;"><?php echo e($title); ?></h1>
                </a>
            </div>
        </div>
    </div>
</section><?php /**PATH /home/u261634547/domains/sattabuzz.com/public_html/resources/views/front/components/fade-logo.blade.php ENDPATH**/ ?>