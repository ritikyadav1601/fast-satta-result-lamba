<section class="topboxnew">
    <?php
        $setting = App\Models\Setting::pluck('value', 'key')->toArray();
    ?>
    <div class="container-fluid">
        <div class="col-md-16 nopadding">
            <div class="newnav">
                <ul>
                    <li><a class="<?php echo e(Route::currentRouteName() == 'front.home' ? 'active' : ''); ?>" href="<?php echo e(route('front.home')); ?>">Home</a></li>
                    <li><a class="<?php echo e(Route::currentRouteName() == 'front.chart' ? 'active' : ''); ?>" href="<?php echo e(route('front.chart')); ?>">Chart</a></li>
                    <li><a class="<?php echo e(Route::currentRouteName() == 'front.contact' ? 'active' : ''); ?>" href="<?php echo e(route('front.contact')); ?>">Contact</a></li>
                    <li><a class="<?php echo e(Route::currentRouteName() == 'front.disclaimer' ? 'active' : ''); ?>" href="<?php echo e(route('admin.login')); ?>">Login</a></li>
                </ul>
                <div class="clearfix"></div>
            </div>
            <div class="text_slide">
                <marquee style="color: rgb(255, 255, 255);">
                    <?php if(Route::currentRouteName() == 'front.home'): ?>

                    <p style="font-size: 16px; text-align: center;"><?php echo e($settings['home_page_float_text']); ?></p>
                <?php else: ?>

                    <p style="font-size: 16px; text-align: center;"><?php echo e($setting['secondary_page_float_text']); ?></p>
                    <?php endif; ?>
                </marquee>
            </div>
        </div>
    </div>
</section>
<?php /**PATH C:\laragon\www\fast\resources\views/front/layout/header.blade.php ENDPATH**/ ?>