<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>24 Satta King</title>
    <link rel="icon" type="image/x-icon" href="<?php echo e(asset('assets/img/logo.png')); ?>">
    <link rel="stylesheet" href=<?php echo e(asset('assets/css/main.css')); ?>>
    <?php echo $__env->yieldPushContent('style'); ?>
</head>
<body>
<?php echo $__env->make('front.layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->yieldContent('content'); ?>

<?php echo $__env->make('front.layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->yieldPushContent('script'); ?>

</body>
</html>
<?php /**PATH C:\laragon\www\24king\resources\views/front/layout/master.blade.php ENDPATH**/ ?>