<div style="box-sizing: border-box; position: relative; display: flex; flex-direction: column; max-width: 100%; margin: 0.5rem auto; background-color: rgb(255, 255, 255); overflow: hidden; border: 0px; border-radius: 0.25rem;">
    <div class="row">
        <div class="card-body" style="flex: 1 1 auto; min-height: 1px; padding: 1.25rem; border: 1px dashed red; background: rgb(255, 216, 0); border-radius: 20px; font-weight: bold; text-align: center; text-transform: uppercase;">
            <h3>CHECK UPDATED SHREE GANESH SATTA KING CHART <a href="https://a1-satta.com/shri-ganesh" rel="noopener noreferrer" target="_blank">HERE</a></h3>
        </div>
    </div>
</div><?php /**PATH C:\laragon\www\sattabuzz\resources\views/front/components/chart-visit-link.blade.php ENDPATH**/ ?>