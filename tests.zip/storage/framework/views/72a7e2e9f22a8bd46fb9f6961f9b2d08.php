<div> footer </div>
<?php /**PATH C:\laragon\www\fast-satta-result\resources\views/admin/layout/footer.blade.php ENDPATH**/ ?>