

<?php $__env->startSection('content'); ?>


    <section class="tablebox1" style="margin: 0px 0px 5px;">
        <div class="container">
            <div class="row">
                <div class="col-md-12 text-center">
                    <h1>Edit Question And Answer</h1>
                </div>
            </div>
        </div>
    </section>
    <section class="tablebox1">
        <div class="container">
            <div class="row">
                <div class="col-md-12 text-center">
                    <form action="<?php echo e(route('question.update', $question->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <div class="mb-3">
                            <label for="question" class="form-label">Question</label>
                            <input type="text" class="form-control" id="question" name="question" value="<?php echo e($question->question); ?>">
                        </div>
                        <div class="mb-3">
                            <label for="answer" class="form-label">Answer</label>
                            <input type="text" class="form-control" id="answer" name="answer" value="<?php echo e($question->answer); ?>">
                        </div>
                        <button type="submit" class="btn btn-primary">Update</button>
                    </form>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u261634547/domains/sattabuzz.com/public_html/resources/views/admin/qa/edit.blade.php ENDPATH**/ ?>