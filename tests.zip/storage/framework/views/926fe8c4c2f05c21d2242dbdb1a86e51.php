

<?php $__env->startSection('content'); ?>
<div class="relative overflow-x-auto shadow-md sm:rounded-lg">
    <form action="<?php echo e(route('bulk.result.update', $oldResult->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="flex flex-col">
            <label for="result">Result</label>
            <input type="text" name="result" value="<?php echo e($oldResult->result); ?>" class=" w-1/2 border-2 border-gray-300 rounded-md p-2">
        </div>
        <button type="submit" class="bg-blue-500 text-white px-4 py-2 rounded-md">Update</button>
    </form>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u261634547/domains/sattabuzz.com/public_html/resources/views/admin/result/bulk-result-edit.blade.php ENDPATH**/ ?>