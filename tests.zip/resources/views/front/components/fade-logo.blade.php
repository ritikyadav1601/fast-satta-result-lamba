<section class="sattalogo">
    <div class="container">
        <div class="row">
            <div class="col-md-12 text-center">
                <!--<a title="Fast-Satta-Result" href="/" class="blink" style="display: inline; opacity: 0.877126;">-->
                    <h1 style="margin: 0px; font-weight: 700;">{{ $title }}</h1>
                <!--</a>-->
            </div>
        </div>
    </div>
</section>