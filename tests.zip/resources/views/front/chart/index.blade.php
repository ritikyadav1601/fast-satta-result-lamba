@extends('front.layout.master')

@section('title', 'Satta Result Chart 2026 – Gali, Desawar, Faridabad Records')
@section('meta_description', 'Access detailed satta result chart for 2026 including Gali, Desawar, Faridabad. Complete record list for daily analysis.')
@section('meta_keywords', 'Satta Result Chart, Gali Chart, Desawar History,2026 Record,Daily Result List')

@section('content')

@include('front.components.fade-logo',['title' => $settings['website_name']])

<section class="circlebox">
    <div class="container">
        <div class="row">
            <div class="col-md-12 text-center">
                <div class="liveresult">
                    <h1 class="hintext2">Satta Result Chart.</h1>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="octoberresultchart">
    <div class="container">
        <div class="row">
            <div class="col-md-12 text-center">
                <h2>Gali Chart, Desawar History</h2>
            </div>
        </div>
    </div>
</section>

<section class="octoberresultchart">
    <div class="container">
        <div class="row">
            <div class="col-md-12 text-center">
                <h2>SATTA KING CHART</h2>
            </div>
        </div>
    </div>
</section>

<section class="octoberresultchart">
    <div class="container">
        <div class="row">
            <div class="col-md-12 text-center">
                <h3>2026 Record, Daily Result List</h3>
            </div>
        </div>
    </div>
</section>

<section class="newtable">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12 nopadding">
                <div class="table-responsive marginBottom">
                    <table class="table table-bordered table-extra">
                        <thead>
                            <tr>
                                <th class="table_chart_section forfirtcolor text-center">Game</th>
                                <th class="table_chart_section forfirtcolor text-center">2026</th>
                                <th class="table_chart_section forfirtcolor text-center">2025</th>
                                <th class="table_chart_section forfirtcolor text-center">2024</th>
                                <th class="table_chart_section forfirtcolor text-center">2023</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach($games as $game)
                            <tr>
                                <td class="table_chart_section forfirtcolor text-center">
                                    {{ strtoupper($game->name) }}
                                </td>

                                <td class="text-center">
                                    <a href="{{ route('game.show', $game->id) }}?year=2026">2026</a>
                                </td>

                                <td class="text-center">
                                    <a href="{{ route('game.show', $game->id) }}?year=2025">2025</a>
                                </td>

                                <td class="text-center">
                                    <a href="{{ route('game.show', $game->id) }}?year=2024">2024</a>
                                </td>

                                <td class="text-center">
                                    <a href="{{ route('game.show', $game->id) }}?year=2023">2023</a>
                                </td>
                            </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</section>

@include('front.components.chart-links')

@endsection