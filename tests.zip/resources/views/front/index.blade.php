@extends('front.layout.master')
@section('title', 'Fast Satta Result | Satta Fast, Faridabad, King, Satta King')
@section('meta_description', 'Fast Satta Result par paye satta fast result, Faridabad satta fast, satta king info aur 36 jodi telegram chart bilkul free. Aaj ka result dekhein abhi!.')
@section('meta_keywords', 'home, awesome site, welcome,fast satta king')
@section('canonical')
<link rel="canonical" href="https://fast-satta-result.com/" />
@endsection
@section('content')
@include('front.components.fade-logo' ,['title' => $settings['website_name']])
@include('front.components.updated-box',['games' => $games, 'gamess' => $gamess])
 @include('front.components.chart-visit-link')
@include('front.components.home-timing-detail',['games' => $games,'settings' => $settings,'otherChart' => $otherChart])

@include('front.components.daily-result-table',['games' => $games])
@if($extraGames->count() > 0)
    @include('front.components.extra-daily-result-table',['extraGames' => $extraGames])
@endif
    @include('front.components.record-chart')
    @include('front.components.faq',['faq' => $faq , 'qa' => $qa])
@endsection
